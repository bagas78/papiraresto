   <div class="modal fade" id="dialogBrg">
	<div class="modal-dialog modal-lg">
	  <div class="modal-content">
		<div class="modal-header">
		  <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
		  </button>
		  <h4 class="modal-title" id="dialogBrg">Daftar Barang</h4>
		</div>
		<div class="modal-body">
		 <table id="barang_operasional" width="100%" class="table table-striped table-bordered">
			  <thead>
				<tr>
				  <th>Barcode</th>
				  <th>Nama Item</th>
				  <th>Satuan</th>
				  <th>Harga Beli</th>
				  <th>Harga Jual</th>
				  <th>Opsi</th>
				</tr>
			  </thead>
			</table>
			<div class="modal-footer">
			</div>
		</div>
	  </div>
	</div>
  </div>