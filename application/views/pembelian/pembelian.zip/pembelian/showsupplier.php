   <div class="modal fade" id="showSupplierModal">
	<div class="modal-dialog modal-lg">
	  <div class="modal-content">
		<div class="modal-header">
		  <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
		  </button>
		  <h4 class="modal-title" id="showSupplierModal">Daftar Supplier</h4>
		</div>
		<div class="modal-body">
		 <table id="daftarsupplier" width="100%" class="table table-striped table-bordered">
			  <thead>
				<tr>
				  <th>Kode</th>
				  <th>Nama Supplier</th>
				  <th>Telp</th>
				  <th>Email</th>
				  <th>Bank</th>
				  <th>Rekening</th>
				  <th>Alamat</th>
				  <th>Opsi</th>
				</tr>
			  </thead>
			</table>
			<div class="modal-footer">
			</div>
		</div>
	  </div>
	</div>
  </div>